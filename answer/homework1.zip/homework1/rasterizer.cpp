#include "rasterizer.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

Rasterizer::Rasterizer(int h, int w, float fov_, float near_, float far_) {
	width_viewport = w;
	height_viewport = h;
	aspect_ratio = float(w) / float(h); // width / height
	fov = fov_;
	near = near_;
	far = far_;
	color_buffer = std::vector<float>(height_viewport * width_viewport * 4, 0.0f);
	depth_buffer = std::vector<float>(height_viewport * width_viewport, std::numeric_limits<float>::lowest());
}

void Rasterizer::set_model_mat(const Matrix4f& m) {
	model_mat = m;
}

void Rasterizer::set_view_mat(const Matrix4f& v) {
	view_mat = v;
}

void Rasterizer::set_projection_mat(const Matrix4f& p) {
	projection_mat = p;
}

void Rasterizer::write_color_to_image(const std::string path) {
	std::vector<unsigned char> img_buffer(color_buffer.size(), 0);
	for (int i = 0; i < color_buffer.size(); ++i) {
		img_buffer[i] = unsigned char(color_buffer[i] * 255.0f + 0.5f);
		// alpha channel always set 255
		if (i % 4 == 3) img_buffer[i] = 255;
	}
	stbi_flip_vertically_on_write(true);
	stbi_write_png(path.c_str(), width_viewport, height_viewport, 4, img_buffer.data(), 0);
}

void Rasterizer::draw_line(int x0, int y0, int x1, int y1, const Vector4f& color) {
	bool steep = false;
	if (std::abs(x1 - x0) < std::abs(y1 - y0)) {
		steep = true;
		std::swap(x0, y0);
		std::swap(x1, y1);
	}
	if (x0 > x1) {
		std::swap(x0, x1);
		std::swap(y0, y1);
	}
	int dx = x1 - x0, dy = y1 - y0;
	int de2 = std::abs(dy) * 2;
	int e2 = 0;
	int y = y0;
	int ystep = dy > 0 ? 1 : -1;
	for (int x = x0; x <= x1; ++x) {
		if (steep) {
			//draw(y, x)
			int idx_ = (x * width_viewport + y) * 4;
			color_buffer[idx_++] = color[0];
			color_buffer[idx_++] = color[1];
			color_buffer[idx_++] = color[2];
			color_buffer[idx_++] = color[3];
		}
		else {
			//draw(x,y)
			int idx_ = (y * width_viewport + x)* 4;
			color_buffer[idx_++] = color[0];
			color_buffer[idx_++] = color[1];
			color_buffer[idx_++] = color[2];
			color_buffer[idx_++] = color[3];
		}
		e2 += de2;
		if (e2 > dx) {
			y += ystep;
			e2 -= dx * 2;
		}
	}
}

inline Vector4f Rasterizer::vec3_to_vec4(const Vector3f& v, float w) {
	return Vector4f(v(0), v(1), v(2), w);
}

inline Vector2i Rasterizer::viewport_trans(const Vector4f& p) {
	int x0 = int(0.5f * (p.x() + 1.0f) * width_viewport);
	int y0 = int(0.5f * (p.y() + 1.0f) * height_viewport);
	return Vector2i(x0, y0);
}

void Rasterizer::draw_frameware(const Vector4f& color) {
	Matrix4f mvp = projection_mat * view_mat * model_mat;
	for (int i = 0; i < mesh.indices.size(); ++i) {
		Vector4f p0_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][0]], 1.0f);
		float tmp_w = p0_ndc.w();
		p0_ndc /= tmp_w;
		p0_ndc.w() = 1.0f / tmp_w;
		Vector4f p1_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][3]], 1.0f);
		tmp_w = p1_ndc.w();
		p1_ndc /= tmp_w;
		p1_ndc.w() = 1.0f / tmp_w;
		Vector4f p2_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][6]], 1.0f);
		tmp_w = p2_ndc.w();
		p2_ndc /= tmp_w;
		p2_ndc.w() = 1.0f / tmp_w;
		// viewport transform
		Vector2i p0_image = viewport_trans(p0_ndc);
		if (p0_image.x() < 0 || p0_image.x() >= width_viewport || p0_image.y() < 0 || p0_image.y() >= height_viewport)
			continue;
		Vector2i p1_image = viewport_trans(p1_ndc);
		if (p1_image.x() < 0 || p1_image.x() >= width_viewport || p1_image.y() < 0 || p1_image.y() >= height_viewport)
			continue;
		Vector2i p2_image = viewport_trans(p2_ndc);
		if (p2_image.x() < 0 || p2_image.x() >= width_viewport || p2_image.y() < 0 || p2_image.y() >= height_viewport)
			continue;
		draw_line(p0_image.x(), p0_image.y(), p1_image.x(), p1_image.y(), color);
		draw_line(p0_image.x(), p0_image.y(), p2_image.x(), p2_image.y(), color);
		draw_line(p2_image.x(), p2_image.y(), p1_image.x(), p1_image.y(), color);
	}
}