#pragma once

#include <limits>
#include <cmath>
//#include <algorithm> 

#include "mesh.h"
//#define STBI_WINDOWS_UTF8


class Rasterizer {

public:
	Rasterizer() {}
	Rasterizer(int h = 700, int w = 700, float fov_ = 45.0, float near_ = -0.1, float far_ = -50.0);

	void set_model_mat(const Matrix4f& m);
	void set_view_mat(const Matrix4f& v);
	void set_projection_mat(const Matrix4f& p);
	void draw_line(int x0, int y0, int x1, int y1, const Vector4f& color);
	void draw_frameware(const Vector4f& color);
	void draw_trangles();
	void write_color_to_image(const std::string path);
	void write_depth_to_image(const std::string path);

	inline Vector4f vec3_to_vec4(const Vector3f& v, float w);
	inline Vector2i viewport_trans(const Vector4f& p);

public:
	int height_viewport, width_viewport;
	float fov, near, far, aspect_ratio;
	Vector3f cam_pos;
	Matrix4f model_mat, view_mat, projection_mat;
	std::vector<float> color_buffer;
	std::vector<float> depth_buffer;
	Mesh mesh;
};
