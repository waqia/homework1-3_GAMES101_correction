#include "mesh.h"
#include "rasterizer.h"

Eigen::Matrix4f get_view_matrix(const Vector3f& campos, const Vector3f& lookto, const Vector3f& yup)
{
    Vector3f z = (campos - lookto).normalized();
    Vector3f x = yup.cross(z).normalized();
    Vector3f y = z.cross(x);
    Matrix4f view_mat;
    view_mat << x[0], x[1], x[2], 0.0f,
        y[0], y[1], y[2], 0.0f,
        z[0], z[1], z[2], 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f;
    Eigen::Matrix4f trans = Eigen::Matrix4f::Identity();
    trans(0, 3) = -campos[0];
    trans(1, 3) = -campos[1];
    trans(2, 3) = -campos[2];
    view_mat = view_mat * trans;

    return view_mat;
}

Eigen::Matrix4f get_model_matrix(float rotation_angle)
{
    Eigen::Matrix4f model = Eigen::Matrix4f::Identity();

    // TODO: Implement this function
    // Create the model matrix for rotating the triangle around the Z axis.
    // Then return it.

    AngleAxisf rot(rotation_angle * 3.14159265f / 180.0f, Vector3f(0, 0, 1));
    Isometry3f tt = Isometry3f::Identity();
    model = tt.rotate(rot).matrix();

    return model;
}

Eigen::Matrix4f get_model_matrix(Vector3f axis, float rotation_angle)
{
    Eigen::Matrix4f model = Eigen::Matrix4f::Identity();

    // TODO: Implement this function
    // Create the model matrix for rotating the triangle around the axis.
    // Then return it.

    AngleAxisf rot(rotation_angle * 3.14159265f / 180.0f, axis.normalized());
    Isometry3f tt = Isometry3f::Identity();
    model = tt.rotate(rot).matrix();

    return model;
}

// ͶӰ������õ�����ϵͳ��games101�γ�����һ�£��� zNear��zFar���Ǹ�ֵ��
// ͶӰ�任������ͶӰ��[-1,1]���������У���ʱz��ֵԽ�󣬾����������
Eigen::Matrix4f get_projection_matrix(float eye_fov, float aspect_ratio,
    float zNear, float zFar)
{
    // Students will implement this function

    Eigen::Matrix4f projection = Eigen::Matrix4f::Identity();

    // TODO: Implement this function
    // Create the projection matrix for the given parameters.
    // Then return it.

    float tan_half_fov = tan(eye_fov / 2.0f / 180.0f * 3.14159265f);
    float t_ = -zNear * tan_half_fov; // znear and zfar are negative
    float r_ = t_ * aspect_ratio;
    projection << zNear / r_, 0.f, 0.f, 0.f,
        0.f, zNear / t_, 0.f, 0.f,
        0.f, 0.f, (zFar + zNear) / (zNear - zFar), 2.0f * zNear * zFar / (zFar - zNear),
        0.f, 0.f, 1.f, 0.f;


    return projection;
}

int main() {
    // ���ڴ�������ת�Ƕ�
    float angle = 0.0f;
    // ������դ����Ⱦ��
	Rasterizer rd(700, 700,  45.0f, -0.1f, -50.0f);
    // ����model�任����
    rd.set_model_mat(get_model_matrix(angle));
    //rd.set_model_mat(get_model_matrix(Vector3f(0,1,0), angle));
    // ����view�任����
    rd.set_view_mat(get_view_matrix(Vector3f(0., 0., 5.), Vector3f(0., 0., 0.), Vector3f(0., 1., 0.)));
    // ����projection�任����
    rd.set_projection_mat(get_projection_matrix(45.f, 1.f, -0.1f, -50.f));
    // ����������
    rd.mesh.vertices.emplace_back(Eigen::Vector3f(2, 0, -2));
    rd.mesh.vertices.emplace_back(Eigen::Vector3f(0, 2, -2));
    rd.mesh.vertices.emplace_back(Eigen::Vector3f(-2, 0, -2));
    std::array<unsigned int, 9> idx{ 0, 0, 0, 1, 1, 1, 2, 2, 2 };
    rd.mesh.indices.emplace_back(idx);
    // ��Ⱦ�����α߿�
    rd.draw_frameware(Vector4f(1.0, 1.0, 1.0, 1.0));
	// ��������ͼ��
	rd.write_color_to_image("output.png");
}