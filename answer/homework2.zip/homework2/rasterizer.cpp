#include "rasterizer.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

Rasterizer::Rasterizer(int h, int w, float fov_, float near_, float far_, bool do_ssaa) {
	width_viewport = w;
	height_viewport = h;
	aspect_ratio = float(w) / float(h); // width / height
	fov = fov_;
	near = near_;
	far = far_;
	do_SSAA = do_ssaa;
	color_buffer = std::vector<float>(height_viewport * width_viewport * 4, 0.0f);
	if(do_SSAA)
		depth_buffer = std::vector<float>(height_viewport * width_viewport * 4, std::numeric_limits<float>::lowest());
	else
		depth_buffer = std::vector<float>(height_viewport * width_viewport, std::numeric_limits<float>::lowest());
}

void Rasterizer::set_model_mat(const Matrix4f& m) {
	model_mat = m;
}

void Rasterizer::set_view_mat(const Matrix4f& v) {
	view_mat = v;
}

void Rasterizer::set_projection_mat(const Matrix4f& p) {
	projection_mat = p;
}

void Rasterizer::write_color_to_image(const std::string path) {
	std::vector<unsigned char> img_buffer(color_buffer.size(), 0);
	for (int i = 0; i < color_buffer.size(); ++i) {
		img_buffer[i] = unsigned char(color_buffer[i] * 255.0f + 0.5f);
		// alpha channel always set 255
		if (i % 4 == 3) img_buffer[i] = 255;
	}
	stbi_flip_vertically_on_write(true);
	stbi_write_png(path.c_str(), width_viewport, height_viewport, 4, img_buffer.data(), 0);
}

void Rasterizer::draw_line(int x0, int y0, int x1, int y1, const Vector4f& color) {
	bool steep = false;
	if (std::abs(x1 - x0) < std::abs(y1 - y0)) {
		steep = true;
		std::swap(x0, y0);
		std::swap(x1, y1);
	}
	if (x0 > x1) {
		std::swap(x0, x1);
		std::swap(y0, y1);
	}
	int dx = x1 - x0, dy = y1 - y0;
	int de2 = std::abs(dy) * 2;
	int e2 = 0;
	int y = y0;
	int ystep = dy > 0 ? 1 : -1;
	for (int x = x0; x <= x1; ++x) {
		if (steep) {
			//draw(y, x)
			int idx_ = (x * width_viewport + y) * 4;
			color_buffer[idx_++] = color[0];
			color_buffer[idx_++] = color[1];
			color_buffer[idx_++] = color[2];
			color_buffer[idx_++] = color[3];
		}
		else {
			//draw(x,y)
			int idx_ = (y * width_viewport + x)* 4;
			color_buffer[idx_++] = color[0];
			color_buffer[idx_++] = color[1];
			color_buffer[idx_++] = color[2];
			color_buffer[idx_++] = color[3];
		}
		e2 += de2;
		if (e2 > dx) {
			y += ystep;
			e2 -= dx * 2;
		}
	}
}

inline Vector4f Rasterizer::vec3_to_vec4(const Vector3f& v, float w) {
	return Vector4f(v(0), v(1), v(2), w);
}

inline Vector2f Rasterizer::viewport_trans(const Vector4f& p) {
	float x0 = 0.5f * (p.x() + 1.0f) * width_viewport;
	float y0 = 0.5f * (p.y() + 1.0f) * height_viewport;
	return Vector2f(x0, y0);
}

inline void Rasterizer::set_pixel(int x, int y, const Vector3f& color) {
	int idx_ = (x + y * width_viewport) * 4;
	color_buffer[idx_++] = color(0);
	color_buffer[idx_++] = color(1);
	color_buffer[idx_++] = color(2);
	color_buffer[idx_++] = 1.0;
}

void Rasterizer::clear_depth_buffer() {
	for (auto& i : depth_buffer)
		i = std::numeric_limits<float>::lowest();
}

void Rasterizer::clear_color_buffer() {
	for (int i = 0; i < color_buffer.size(); ++i) {
		color_buffer[i] = 0.0f;
		if (i%4 == 3)
			color_buffer[i] = 1.0f;
	}
}


void Rasterizer::draw_frameware(const Vector4f& color) {
	Matrix4f mvp = projection_mat * view_mat * model_mat;
	for (int i = 0; i < mesh.indices.size(); ++i) {
		Vector4f p0_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][0]], 1.0f);
		float tmp_w = p0_ndc.w();
		p0_ndc /= tmp_w;
		p0_ndc.w() = 1.0f / tmp_w;
		Vector4f p1_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][3]], 1.0f);
		tmp_w = p1_ndc.w();
		p1_ndc /= tmp_w;
		p1_ndc.w() = 1.0f / tmp_w;
		Vector4f p2_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][6]], 1.0f);
		tmp_w = p2_ndc.w();
		p2_ndc /= tmp_w;
		p2_ndc.w() = 1.0f / tmp_w;
		// viewport transform
		Vector2f tmp_p = viewport_trans(p0_ndc);
		Vector2i p0_image = Vector2i(int(tmp_p.x()), int(tmp_p.y()));
		if (p0_image.x() < 0 || p0_image.x() >= width_viewport || p0_image.y() < 0 || p0_image.y() >= height_viewport)
			continue;
		tmp_p = viewport_trans(p1_ndc);
		Vector2i p1_image = Vector2i(int(tmp_p.x()), int(tmp_p.y()));
		if (p1_image.x() < 0 || p1_image.x() >= width_viewport || p1_image.y() < 0 || p1_image.y() >= height_viewport)
			continue;
		tmp_p = viewport_trans(p2_ndc);
		Vector2i p2_image = Vector2i(int(tmp_p.x()), int(tmp_p.y()));
		if (p2_image.x() < 0 || p2_image.x() >= width_viewport || p2_image.y() < 0 || p2_image.y() >= height_viewport)
			continue;
		draw_line(p0_image.x(), p0_image.y(), p1_image.x(), p1_image.y(), color);
		draw_line(p0_image.x(), p0_image.y(), p2_image.x(), p2_image.y(), color);
		draw_line(p2_image.x(), p2_image.y(), p1_image.x(), p1_image.y(), color);
	}
}

static bool insideTriangle(float x, float y, const Vector2f& p0, const Vector2f& p1, const Vector2f& p2) {
	// ���ϲ�û����ϸ���� �����������εı���ʱ������ж��Ƿ����������ڣ���ο���������
	// https://www.scratchapixel.com/lessons/3d-basic-rendering/rasterization-practical-implementation/rasterization-stage.html
	Vector2f edge0 = p2 - p1, edge1 = p0 - p2, edge2 = p1 - p0;
	float w0 = edge0.x() * (y - p1.y()) - edge0.y() * (x - p1.x());
	float w1 = edge1.x() * (y - p2.y()) - edge1.y() * (x - p2.x());
	float w2 = edge2.x() * (y - p0.y()) - edge2.y() * (x - p0.x());
	bool in_ = true;
	in_ &= (w0 == 0.f ? ((edge0.y() == 0.f && edge0.x() < 0.f)) : (w0 > 0.f));
	in_ &= (w1 == 0.f ? ((edge1.y() == 0.f && edge1.x() < 0.f)) : (w1 > 0.f));
	in_ &= (w2 == 0.f ? ((edge2.y() == 0.f && edge2.y() < 0.f)) : (w2 > 0.f));
	return in_;
}

static Vector3f computeBarycentric2D(float x, float y, const Vector2f& p0, const Vector2f& p1, const Vector2f& p2) {
	Vector2f edge0 = p2 - p1, edge1 = p0 - p2, edge2 = p1 - p0;
	float w0 = edge0.x() * (y - p1.y()) - edge0.y() * (x - p1.x());
	float w1 = edge1.x() * (y - p2.y()) - edge1.y() * (x - p2.x());
	float w2 = edge2.x() * (y - p0.y()) - edge2.y() * (x - p0.x());
	Vector3f coef;
	float area = w0 + w1 + w2;
	coef(0) = w0 / area;
	coef(1) = w1 / area;
	coef(2) = 1.0f - coef(0) - coef(1);
	return coef;
}

void Rasterizer::draw_triangles() {
	Matrix4f mvp = projection_mat * view_mat * model_mat;
	for (int i = 0; i < mesh.indices.size(); ++i) {
		// mvp transform
		// ����mvp�任�Ժ�õ� p0_ndc���۲�ͶӰ�������һ�У����Է���p0_ndc��w���������ϵ�¶����zֵ��
		// Ҳ���Ƕ������ȡ������������γ��������ǽ� 1 / w Ҳ������ȵĵ����洢��p0_ndc.w�У�����
		// �����͸�ӽ�����ֵ������͸�ӽ�����ֵ��ο� https://zhuanlan.zhihu.com/p/144331875
		Vector4f p0_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][0]], 1.0f);
		float tmp_w = p0_ndc.w();
		p0_ndc /= tmp_w;
		p0_ndc.w() = 1.0f / tmp_w; 
		Vector4f p1_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][3]], 1.0f);
		tmp_w = p1_ndc.w();
		p1_ndc /= tmp_w;
		p1_ndc.w() = 1.0f / tmp_w;
		Vector4f p2_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][6]], 1.0f);
		tmp_w = p2_ndc.w();
		p2_ndc /= tmp_w;
		p2_ndc.w() = 1.0f / tmp_w;
		// viewport transform
		Vector2f p0_image = viewport_trans(p0_ndc);
		if (p0_image.x() < 0 || p0_image.x() >= width_viewport || p0_image.y() < 0 || p0_image.y() >= height_viewport)
			continue;
		Vector2f p1_image = viewport_trans(p1_ndc);
		if (p1_image.x() < 0 || p1_image.x() >= width_viewport || p1_image.y() < 0 || p1_image.y() >= height_viewport)
			continue;
		Vector2f p2_image = viewport_trans(p2_ndc);
		if (p2_image.x() < 0 || p2_image.x() >= width_viewport || p2_image.y() < 0 || p2_image.y() >= height_viewport)
			continue;

		// 1 ���㵱ǰ�����ε�bounding box

		// 2 ѭ���ж�bounding box��ÿ�����ص��Ƿ��ڵ�ǰ��������

		// 3 �������������������ڣ���������δ���������ص����
		// Vector3f coeffs = computeBarycentric2D(x_ + 0.5f, y_ + 0.5f, p0_image, p1_image, p2_image);
		// coeffs(0) *= p0_ndc.w();
		// coeffs(1) *= p1_ndc.w();
		// coeffs(2) *= p2_ndc.w();
		// float z_frag = 1.0f / (coeffs(0) + coeffs(1) + coeffs(2)); // z_frag���ǵ�ǰ���ص�����

		// 4 �Ա�z_frag��depth_buffer�е���ֵ���ж��Ƿ�Ӧ�û�������أ����Ӧ�û���������
		// mesh.vertices_color[mesh.indices[i][0]]��mesh.vertices_color[mesh.indices[i][3]]��
		// mesh.vertices_color[mesh.indices[i][6]]����ȡ�����������������ɫ��Ȼ����͸�ӽ�����ֵ��
		// ��ֵ����ǰ���ص���ɫ��Ȼ�����set_pixel����������color_buffer��ע�⣺�������ʵ��SSAA�У�
		// ��Ҫ����set_pixel����Ҫ�ֶ��ۼ�color_buffer��ÿ�����ص���ֵ��

		int x_min = int(std::min({ p0_image.x(), p1_image.x(), p2_image.x() }));
		int y_min = int(std::min({ p0_image.y(), p1_image.y(), p2_image.y() }));
		int x_max = int(std::max({ p0_image.x(), p1_image.x(), p2_image.x() }));
		int y_max = int(std::max({ p0_image.y(), p1_image.y(), p2_image.y() }));
		for (int x_ = x_min; x_ <= x_max; ++x_) {
			for (int y_ = y_min; y_ <= y_max; ++y_) {
				if (!do_SSAA) {
					if (insideTriangle(x_ + 0.5f, y_ + 0.5f, p0_image, p1_image, p2_image)) {
						Vector3f coeffs = computeBarycentric2D(x_ + 0.5f, y_ + 0.5f, p0_image, p1_image, p2_image);
						coeffs(0) *= p0_ndc.w();
						coeffs(1) *= p1_ndc.w();
						coeffs(2) *= p2_ndc.w();
						float z_frag = 1.0f / (coeffs(0) + coeffs(1) + coeffs(2));
						if (z_frag > depth_buffer[x_ + y_ * width_viewport]) {
							depth_buffer[x_ + y_ * width_viewport] = z_frag;
							Vector3f corlor_frag = (coeffs(0) * mesh.vertices_color[mesh.indices[i][0]] +
								coeffs(1) * mesh.vertices_color[mesh.indices[i][3]] +
								coeffs(2) * mesh.vertices_color[mesh.indices[i][6]]) * z_frag;
							set_pixel(x_, y_, corlor_frag);
						}
					}
				}
				else {
					Vector3f color_frag(0, 0, 0);
					int idx_depth_buffer_ = (x_ + y_ * width_viewport) * 4;
					int idx_color_buffer_ = (x_ + y_ * width_viewport) * 4;
					if (insideTriangle(x_ + 0.25f, y_ + 0.25f, p0_image, p1_image, p2_image)) {
						Vector3f coeffs = computeBarycentric2D(x_ + 0.25f, y_ + 0.25f, p0_image, p1_image, p2_image);
						coeffs(0) *= p0_ndc.w(); coeffs(1) *= p1_ndc.w(); coeffs(2) *= p2_ndc.w();
						float z_frag = 1.0f / (coeffs(0) + coeffs(1) + coeffs(2));
						if (z_frag > depth_buffer[idx_depth_buffer_]) {
							depth_buffer[idx_depth_buffer_] = z_frag;
							color_frag = (coeffs(0) * mesh.vertices_color[mesh.indices[i][0]] +
								coeffs(1) * mesh.vertices_color[mesh.indices[i][3]] +
								coeffs(2) * mesh.vertices_color[mesh.indices[i][6]]) * z_frag;
							color_buffer[idx_color_buffer_] += color_frag(0)/4;
							color_buffer[idx_color_buffer_ + 1] += color_frag(1)/4;
							color_buffer[idx_color_buffer_ + 2] += color_frag(2)/4;
						}
					}
					if (insideTriangle(x_ + 0.25f, y_ + 0.75f, p0_image, p1_image, p2_image)) {
						Vector3f coeffs = computeBarycentric2D(x_ + 0.25f, y_ + 0.75f, p0_image, p1_image, p2_image);
						coeffs(0) *= p0_ndc.w(); coeffs(1) *= p1_ndc.w(); coeffs(2) *= p2_ndc.w();
						float z_frag = 1.0f / (coeffs(0) + coeffs(1) + coeffs(2));
						if (z_frag > depth_buffer[idx_depth_buffer_+1]) {
							depth_buffer[idx_depth_buffer_+1] = z_frag;
							color_frag = (coeffs(0) * mesh.vertices_color[mesh.indices[i][0]] +
								coeffs(1) * mesh.vertices_color[mesh.indices[i][3]] +
								coeffs(2) * mesh.vertices_color[mesh.indices[i][6]]) * z_frag;
							color_buffer[idx_color_buffer_] += color_frag(0) / 4;
							color_buffer[idx_color_buffer_ + 1] += color_frag(1) / 4;
							color_buffer[idx_color_buffer_ + 2] += color_frag(2) / 4;
						}
					}
					if (insideTriangle(x_ + 0.75f, y_ + 0.25f, p0_image, p1_image, p2_image)) {
						Vector3f coeffs = computeBarycentric2D(x_ + 0.75f, y_ + 0.25f, p0_image, p1_image, p2_image);
						coeffs(0) *= p0_ndc.w(); coeffs(1) *= p1_ndc.w(); coeffs(2) *= p2_ndc.w();
						float z_frag = 1.0f / (coeffs(0) + coeffs(1) + coeffs(2));
						if (z_frag > depth_buffer[idx_depth_buffer_+2]) {
							depth_buffer[idx_depth_buffer_+2] = z_frag;
							color_frag = (coeffs(0) * mesh.vertices_color[mesh.indices[i][0]] +
								coeffs(1) * mesh.vertices_color[mesh.indices[i][3]] +
								coeffs(2) * mesh.vertices_color[mesh.indices[i][6]]) * z_frag;
							color_buffer[idx_color_buffer_] += color_frag(0) /4;
							color_buffer[idx_color_buffer_ + 1] += color_frag(1)/4;
							color_buffer[idx_color_buffer_ + 2] += color_frag(2)/4;
						}
					}
					if (insideTriangle(x_ + 0.75f, y_ + 0.75f, p0_image, p1_image, p2_image)) {
						Vector3f coeffs = computeBarycentric2D(x_ + 0.75f, y_ + 0.75f, p0_image, p1_image, p2_image);
						coeffs(0) *= p0_ndc.w(); coeffs(1) *= p1_ndc.w(); coeffs(2) *= p2_ndc.w();
						float z_frag = 1.0f / (coeffs(0) + coeffs(1) + coeffs(2));
						if (z_frag > depth_buffer[idx_depth_buffer_+3]) {
							depth_buffer[idx_depth_buffer_+3] = z_frag;
							color_frag = (coeffs(0) * mesh.vertices_color[mesh.indices[i][0]] +
								coeffs(1) * mesh.vertices_color[mesh.indices[i][3]] +
								coeffs(2) * mesh.vertices_color[mesh.indices[i][6]]) * z_frag;
							color_buffer[idx_color_buffer_] += color_frag(0)/4;
							color_buffer[idx_color_buffer_ + 1] += color_frag(1)/4;
							color_buffer[idx_color_buffer_ + 2] += color_frag(2)/4;
						}
					}
				}
			}
		}

	}
}
