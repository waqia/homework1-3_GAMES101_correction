#pragma once

#include <string>
#include <iostream>

#include "eigen-3.4.0/Eigen/Core"
#include "eigen-3.4.0/Eigen/Geometry"
//#include <eigen-3.4.0/Eigen/Geometry>
using namespace Eigen;

class Texture {
public:
	Texture() {}
	Texture(const std::string& img_path, int h, int w, int c);
	~Texture();

	void load_texture_image(const std::string& img_path);
	Vector3f get_color(float u, float v);
	Vector3f get_color(int x, int y);
	Vector3f get_color_bilinear(float u, float v);

	int height, width, channel;

public:
	unsigned char* data;
};