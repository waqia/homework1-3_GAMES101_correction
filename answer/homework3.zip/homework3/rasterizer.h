#pragma once

#include <limits>
#include <cmath>
#include <algorithm> 
#include <functional>

#include "mesh.h"
#include "texture.h"

struct FragmentInfo {
	Eigen::Vector3f world_pos;
	Eigen::Vector3f color;
	Eigen::Vector3f normal;
	Eigen::Vector2f tex_coords;
	Texture* texture;
	Texture* norm_map_texture;
	Matrix3f TBN;
};

class Rasterizer {

public:
	Rasterizer() {}
	Rasterizer(int h = 700, int w = 700, float fov_ = 45.0, float near_ = -0.1, float far_ = -50.0);

	void set_model_mat(const Matrix4f& m);
	void set_view_mat(const Matrix4f& v);
	void set_projection_mat(const Matrix4f& p);
	void draw_line(int x0, int y0, int x1, int y1, const Vector4f& color);
	void draw_frameware(const Vector4f& color);
	void draw_one_triangle(const Vector3f& p0, const Vector3f& p1, const Vector3f& p2, 
		const Vector2f& uv0, const Vector2f& uv1, const Vector2f& uv2, 
		const Vector3f& norm0, const Vector3f& norm1, const Vector3f& norm2,
		const Matrix3f& TBN0, const Matrix3f& TBN1, const Matrix3f& TBN2,
		const Matrix4f& vp_mat);
	void draw_triangles();
	void draw_triangles_with_displacement_mapping();
	void write_color_to_image(const std::string path);
	void write_depth_to_image(const std::string path);

	inline Vector4f vec3_to_vec4(const Vector3f& v, float w);
	inline Vector3f vec4_to_vec3(const Vector4f& v);
	inline Vector2f viewport_trans(const Vector4f& p);
	inline void set_pixel(int x, int y, const Vector3f& color);
	void clear_depth_buffer();
	void clear_color_buffer();

	Matrix3f get_TBN(const Vector3f& p0, const Vector3f& p1, const Vector3f& p2,
		const Vector2f& uv0, const Vector2f& uv1, const Vector2f& uv2, const Vector3f& p0_norm);
	void displace_point(Vector3f& p0, const Vector2f& uv0, Vector3f& norm0, const Matrix3f& TBN0, Texture* hmap_texture);

public:
	int height_viewport, width_viewport;
	float fov, near, far, aspect_ratio;
	Vector3f cam_pos;
	Matrix4f model_mat, view_mat, projection_mat;
	std::vector<float> color_buffer;
	std::vector<float> depth_buffer;
	Mesh mesh;
	Texture* texture;
	Texture* norm_map_texture;

	std::function<Eigen::Vector3f(FragmentInfo)> frag_shader;
};
