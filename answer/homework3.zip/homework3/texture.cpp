#include "texture.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


Texture::Texture(const std::string& img_path, int h, int w, int c) {
	height = h;
	width = w;
	channel = c;
	stbi_set_flip_vertically_on_load(true);
	data = stbi_load(img_path.c_str(), &w, &h, &c, 3);
	if (!data) {
		std::cout << "cannot open " << img_path << std::endl;
		exit(1);
	}
}

Texture::~Texture() {
	stbi_image_free(data);
}

Vector3f Texture::get_color(float u, float v) {
	int x = int(u * width);
	x = std::max(0, std::min(x, width - 1));
	int y = int(v * height);
	y = std::max(0, std::min(y, height - 1));
	int idx_ = (y * width + x) * channel;
	return Vector3f(float(data[idx_]), float(data[idx_ + 1]), float(data[idx_ + 2]));
}

Vector3f Texture::get_color(int x, int y) {
	x = std::max(0, std::min(x, width - 1));
	y = std::max(0, std::min(y, height - 1));
	int idx_ = (y * width + x) * channel;
	return Vector3f(float(data[idx_]), float(data[idx_ + 1]), float(data[idx_ + 2]));
}


Vector3f get_color_bilinear(float u, float v) {
	// �ڴ�ʵ��˫���Բ�ֵ
	return Vector3f(0, 0, 0);
}