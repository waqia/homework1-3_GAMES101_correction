#include "mesh.h"

void Mesh::load_model(const std::string& path) {
	std::ifstream input(path);
	std::string line;
	if (input) {
		while (std::getline(input, line)) {
			if (line.size() < 2)  continue;
			std::istringstream record(line);
			std::string head;
			if (line[0] == 'v') {
				record >> head;
				if (line[1] == ' ') {
					Vector3f tmp_vc;
					record >> tmp_vc[0] >> tmp_vc[1] >> tmp_vc[2];
					vertices.emplace_back(tmp_vc);
				}
				else if (line[1] == 'n') {
					Vector3f tmp_norm;
					record >> tmp_norm[0] >> tmp_norm[1] >> tmp_norm[2];
					norms.emplace_back(tmp_norm);
				}
				else if (line[1] == 't') {
					Vector2f tmp_tc;
					record >> tmp_tc[0] >> tmp_tc[1];
					uvs.emplace_back(tmp_tc);
				}
			}
			else if (line[0] == 'f') {
				for (auto& s : line) {
					if (s == '/')
						s = ' ';
				}
				std::istringstream index_iss(line);
				index_iss >> head;
				std::array<unsigned int, 9> tmp_idx;
				for (int i = 0; i < 9; ++i) {
					index_iss >> tmp_idx[i];
					tmp_idx[i]--;
				}
				indices.emplace_back(tmp_idx);
			}
		}
		input.close();
	}
	else {
		std::cout << "cannot open " << path << std::endl;
		exit(1);
	}
}