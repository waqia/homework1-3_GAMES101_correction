#pragma once

#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <vector>
#include <array>

#include "eigen-3.4.0/Eigen/Core"
#include "eigen-3.4.0/Eigen/Geometry"
//#include <eigen-3.4.0/Eigen/Geometry>
using namespace Eigen;


class Mesh {

public:
	Mesh(const std::string& path) {
		load_model(path);
	}
	Mesh() {}
	void load_model(const std::string& path);

public:
	std::vector<Vector3f> vertices;
	std::vector<Vector3f> vertices_color;
	std::vector<Vector2f> uvs;
	std::vector<Vector3f> norms;
	std::vector<std::array<unsigned int, 9>> indices;
};
