#include "rasterizer.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

Rasterizer::Rasterizer(int h, int w, float fov_, float near_, float far_) {
	width_viewport = w;
	height_viewport = h;
	aspect_ratio = float(w) / float(h); // width / height
	fov = fov_;
	near = near_;
	far = far_;
	color_buffer = std::vector<float>(height_viewport * width_viewport * 4, 0.0f);
	depth_buffer = std::vector<float>(height_viewport * width_viewport, std::numeric_limits<float>::lowest());
	texture = nullptr;
	norm_map_texture = nullptr;
}

void Rasterizer::set_model_mat(const Matrix4f& m) {
	model_mat = m;
}

void Rasterizer::set_view_mat(const Matrix4f& v) {
	view_mat = v;
}

void Rasterizer::set_projection_mat(const Matrix4f& p) {
	projection_mat = p;
}

void Rasterizer::write_color_to_image(const std::string path) {
	std::vector<unsigned char> img_buffer(color_buffer.size(), 0);
	for (int i = 0; i < color_buffer.size(); ++i) {
		float color_ = std::min(1.0f, std::max(0.f, color_buffer[i]));
		img_buffer[i] = unsigned char(color_ * 255.0f);
		// alpha channel always set 255
		if (i % 4 == 3) img_buffer[i] = 255;
	}
	stbi_flip_vertically_on_write(true);
	stbi_write_png(path.c_str(), width_viewport, height_viewport, 4, img_buffer.data(), 0);
}

void Rasterizer::draw_line(int x0, int y0, int x1, int y1, const Vector4f& color) {
	bool steep = false;
	if (std::abs(x1 - x0) < std::abs(y1 - y0)) {
		steep = true;
		std::swap(x0, y0);
		std::swap(x1, y1);
	}
	if (x0 > x1) {
		std::swap(x0, x1);
		std::swap(y0, y1);
	}
	int dx = x1 - x0, dy = y1 - y0;
	int de2 = std::abs(dy) * 2;
	int e2 = 0;
	int y = y0;
	int ystep = dy > 0 ? 1 : -1;
	for (int x = x0; x <= x1; ++x) {
		if (steep) {
			//draw(y, x)
			int idx_ = (x * width_viewport + y) * 4;
			color_buffer[idx_++] = color[0];
			color_buffer[idx_++] = color[1];
			color_buffer[idx_++] = color[2];
			color_buffer[idx_++] = color[3];
		}
		else {
			//draw(x,y)
			int idx_ = (y * width_viewport + x)* 4;
			color_buffer[idx_++] = color[0];
			color_buffer[idx_++] = color[1];
			color_buffer[idx_++] = color[2];
			color_buffer[idx_++] = color[3];
		}
		e2 += de2;
		if (e2 > dx) {
			y += ystep;
			e2 -= dx * 2;
		}
	}
}

inline Vector4f Rasterizer::vec3_to_vec4(const Vector3f& v, float w) {
	return Vector4f(v(0), v(1), v(2), w);
}

inline Vector3f Rasterizer::vec4_to_vec3(const Vector4f& v) {
	return Vector3f(v(0), v(1), v(2));
}

inline Vector2f Rasterizer::viewport_trans(const Vector4f& p) {
	float x0 = 0.5f * (p.x() + 1.0f) * width_viewport;
	float y0 = 0.5f * (p.y() + 1.0f) * height_viewport;
	return Vector2f(x0, y0);
}

inline void Rasterizer::set_pixel(int x, int y, const Vector3f& color) {
	int idx_ = (x + y * width_viewport) * 4;
	color_buffer[idx_++] = color(0);
	color_buffer[idx_++] = color(1);
	color_buffer[idx_++] = color(2);
	color_buffer[idx_++] = 1.0;
}

void Rasterizer::clear_depth_buffer() {
	for (auto& i : depth_buffer)
		i = std::numeric_limits<float>::lowest();
}

void Rasterizer::clear_color_buffer() {
	for (int i = 0; i < color_buffer.size(); ++i) {
		color_buffer[i] = 0.0f;
		if (i%4 == 3)
			color_buffer[i] = 1.0f;
	}
}

Matrix3f Rasterizer::get_TBN(const Vector3f& p0, const Vector3f& p1, const Vector3f& p2,
	const Vector2f& uv0, const Vector2f& uv1, const Vector2f& uv2, const Vector3f& p0_norm) {
	// ����p0���TBN
	Vector3f e1 = p1 - p0;
	Vector3f e2 = p2 - p0;
	float du1 = uv1.x() - uv0.x(), dv1 = uv1.y() - uv0.y();
	float du2 = uv2.x() - uv0.x(), dv2 = uv2.y() - uv0.y();
	Vector3f T = (dv1 * e2 - dv2 * e1) / (dv1 * du2 - dv2 * du1);
	// �õ���������TBN
	Vector3f N = p0_norm.normalized();
	T = (T - T.dot(N) * N).normalized();
	Vector3f B = N.cross(T);
	Matrix3f TBN;
	TBN << T(0), B(0), N(0),
		T(1), B(1), N(1),
		T(2), B(2), N(2);
	return TBN;
}


void Rasterizer::draw_frameware(const Vector4f& color) {
	Matrix4f mvp = projection_mat * view_mat * model_mat;
	for (int i = 0; i < mesh.indices.size(); ++i) {
		Vector4f p0_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][0]], 1.0f);
		float tmp_w = p0_ndc.w();
		p0_ndc /= tmp_w;
		p0_ndc.w() = 1.0f / tmp_w;
		Vector4f p1_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][3]], 1.0f);
		tmp_w = p1_ndc.w();
		p1_ndc /= tmp_w;
		p1_ndc.w() = 1.0f / tmp_w;
		Vector4f p2_ndc = mvp * vec3_to_vec4(mesh.vertices[mesh.indices[i][6]], 1.0f);
		tmp_w = p2_ndc.w();
		p2_ndc /= tmp_w;
		p2_ndc.w() = 1.0f / tmp_w;
		// viewport transform
		Vector2f tmp_p = viewport_trans(p0_ndc);
		Vector2i p0_image = Vector2i(int(tmp_p.x()), int(tmp_p.y()));
		if (p0_image.x() < 0 || p0_image.x() >= width_viewport || p0_image.y() < 0 || p0_image.y() >= height_viewport)
			continue;
		tmp_p = viewport_trans(p1_ndc);
		Vector2i p1_image = Vector2i(int(tmp_p.x()), int(tmp_p.y()));
		if (p1_image.x() < 0 || p1_image.x() >= width_viewport || p1_image.y() < 0 || p1_image.y() >= height_viewport)
			continue;
		tmp_p = viewport_trans(p2_ndc);
		Vector2i p2_image = Vector2i(int(tmp_p.x()), int(tmp_p.y()));
		if (p2_image.x() < 0 || p2_image.x() >= width_viewport || p2_image.y() < 0 || p2_image.y() >= height_viewport)
			continue;
		draw_line(p0_image.x(), p0_image.y(), p1_image.x(), p1_image.y(), color);
		draw_line(p0_image.x(), p0_image.y(), p2_image.x(), p2_image.y(), color);
		draw_line(p2_image.x(), p2_image.y(), p1_image.x(), p1_image.y(), color);
	}
}

static bool insideTriangle(float x, float y, const Vector2f& p0, const Vector2f& p1, const Vector2f& p2) {
	// ���ϲ�û����ϸ���� �����������εı���ʱ������ж��Ƿ����������ڣ���ο���������
	// https://www.scratchapixel.com/lessons/3d-basic-rendering/rasterization-practical-implementation/rasterization-stage.html
	Vector2f edge0 = p2 - p1, edge1 = p0 - p2, edge2 = p1 - p0;
	float w0 = edge0.x() * (y - p1.y()) - edge0.y() * (x - p1.x());
	float w1 = edge1.x() * (y - p2.y()) - edge1.y() * (x - p2.x());
	float w2 = edge2.x() * (y - p0.y()) - edge2.y() * (x - p0.x());
	bool in_ = true;
	in_ &= (w0 == 0.f ? ((edge0.y() == 0.f && edge0.x() < 0.f)) : (w0 > 0.f));
	in_ &= (w1 == 0.f ? ((edge1.y() == 0.f && edge1.x() < 0.f)) : (w1 > 0.f));
	in_ &= (w2 == 0.f ? ((edge2.y() == 0.f && edge2.y() < 0.f)) : (w2 > 0.f));
	return in_;
}

static Vector3f computeBarycentric2D(float x, float y, const Vector2f& p0, const Vector2f& p1, const Vector2f& p2) {
	Vector2f edge0 = p2 - p1, edge1 = p0 - p2, edge2 = p1 - p0;
	float w0 = edge0.x() * (y - p1.y()) - edge0.y() * (x - p1.x());
	float w1 = edge1.x() * (y - p2.y()) - edge1.y() * (x - p2.x());
	float w2 = edge2.x() * (y - p0.y()) - edge2.y() * (x - p0.x());
	Vector3f coef;
	float area = w0 + w1 + w2;
	coef(0) = w0 / area;
	coef(1) = w1 / area;
	coef(2) = 1.0f - coef(0) - coef(1);
	return coef;
}


// p0 p1 p2 ��������������������������ϵ������
// uv0 uv1 uv2 �������������������
// norm0 norm1 norm2 ��������������������ϵ�µķ�����
// TBN0 TBN1 TBN2 ������������пռ������������������bump mapping��displacement mapping
// vp_mat��ͶӰ�������view����
void Rasterizer::draw_one_triangle(const Vector3f& p0, const Vector3f& p1, const Vector3f& p2,
	const Vector2f& uv0, const Vector2f& uv1, const Vector2f& uv2,
	const Vector3f& norm0, const Vector3f& norm1, const Vector3f& norm2,
	const Matrix3f& TBN0, const Matrix3f& TBN1, const Matrix3f& TBN2,
	const Matrix4f& vp_mat) {

	// mvp�任��p0_ndc��ʾp0�ڱ�׼�豸�ռ�����꣬p0_ndc.w�Ƕ�����view����ϵ�µ�z�ĵ���������
	// ����������Ĳ�ֵ����
	Vector4f p0_ndc = vp_mat * vec3_to_vec4(p0, 1.0f);
	float tmp_w = p0_ndc.w();
	p0_ndc /= tmp_w;
	p0_ndc.w() = 1.0f / tmp_w;
	Vector4f p1_ndc = vp_mat * vec3_to_vec4(p1, 1.0f);
	tmp_w = p1_ndc.w();
	p1_ndc /= tmp_w;
	p1_ndc.w() = 1.0f / tmp_w;
	Vector4f p2_ndc = vp_mat * vec3_to_vec4(p2, 1.0f);
	tmp_w = p2_ndc.w();
	p2_ndc /= tmp_w;
	p2_ndc.w() = 1.0f / tmp_w;
	// �ӿڱ任
	Vector2f p0_image = viewport_trans(p0_ndc);
	if (p0_image.x() < 0 || p0_image.x() >= width_viewport || p0_image.y() < 0 || p0_image.y() >= height_viewport)
		return;
	Vector2f p1_image = viewport_trans(p1_ndc);
	if (p1_image.x() < 0 || p1_image.x() >= width_viewport || p1_image.y() < 0 || p1_image.y() >= height_viewport)
		return;
	Vector2f p2_image = viewport_trans(p2_ndc);
	if (p2_image.x() < 0 || p2_image.x() >= width_viewport || p2_image.y() < 0 || p2_image.y() >= height_viewport)
		return;


	// 1 ���㵱ǰ�����ε�bounding box

	// 2 ѭ���ж�bounding box��ÿ�����ص��Ƿ��ڵ�ǰ��������

	// 3 �������������������ڣ���������δ���������ص����
	// Vector3f coeffs = computeBarycentric2D(x_ + 0.5f, y_ + 0.5f, p0_image, p1_image, p2_image);
	// coeffs(0) *= p0_ndc.w();
	// coeffs(1) *= p1_ndc.w();
	// coeffs(2) *= p2_ndc.w();
	// float z_frag = 1.0f / (coeffs(0) + coeffs(1) + coeffs(2)); // z_frag���ǵ�ǰ���ص�����
	// coeffs = coeffs * z_frag; //��ʱ��coeffs�����͸�ӽ�����ֵ

	// 4 �Ա�z_frag��depth_buffer�е���ֵ���ж��Ƿ�Ӧ�û�������أ����Ӧ�û���
	// ��͸�ӽ�����ֵ������������ϵ������ֵ��ǰ���ص�ĸ������ԣ����浽FragmentInfo frag_info_�У�
	// ����fragment_shader��Ⱦ�����⻹��Ҫ����frag_info_������:
	// frag_info_.texture = texture; //����kd������
	// frag_info_.norm_map_texture = norm_map_texture; // ����bump��displacement mapping������
	// ������set_pexel������Ⱦ�Ľ��

	int x_min = int(std::min({ p0_image.x(), p1_image.x(), p2_image.x() }));
	int y_min = int(std::min({ p0_image.y(), p1_image.y(), p2_image.y() }));
	int x_max = int(std::max({ p0_image.x(), p1_image.x(), p2_image.x() }));
	int y_max = int(std::max({ p0_image.y(), p1_image.y(), p2_image.y() }));
	for (int x_ = x_min; x_ <= x_max; ++x_) {
		for (int y_ = y_min; y_ <= y_max; ++y_) {
			if (insideTriangle(x_ + 0.5f, y_ + 0.5f, p0_image, p1_image, p2_image)) {
				Vector3f coeffs = computeBarycentric2D(x_ + 0.5f, y_ + 0.5f, p0_image, p1_image, p2_image);
				coeffs(0) *= p0_ndc.w();
				coeffs(1) *= p1_ndc.w();
				coeffs(2) *= p2_ndc.w();
				float z_frag = 1.0f / (coeffs(0) + coeffs(1) + coeffs(2));
				if (z_frag > depth_buffer[x_ + y_ * width_viewport]) {
					depth_buffer[x_ + y_ * width_viewport] = z_frag;
					FragmentInfo frag_info_;
					frag_info_.normal = (coeffs(0) * norm0 + coeffs(1) * norm1 + coeffs(2) * norm2) * z_frag;
					frag_info_.normal.normalize();
					frag_info_.world_pos = (coeffs(0) * p0 + coeffs(1) * p1 + coeffs(2) * p2) * z_frag;
					frag_info_.tex_coords = (coeffs(0) * uv0 + coeffs(1) * uv1 + coeffs(2) * uv2) * z_frag;
					frag_info_.TBN = (coeffs(0) * TBN0 + coeffs(1) * TBN1 + coeffs(2) * TBN2) * z_frag;
					if (texture)
						frag_info_.texture = texture;
					if (norm_map_texture)
						frag_info_.norm_map_texture = norm_map_texture;
					Vector3f corlor_frag = frag_shader(frag_info_);
					set_pixel(x_, y_, corlor_frag);
				}
			}
		}
	}
}


void Rasterizer::draw_triangles() {
	Matrix4f vp = projection_mat * view_mat;
	Matrix4f norm_mat = model_mat.inverse().transpose();
	for (int i = 0; i < mesh.indices.size(); ++i) {
		Vector3f p0 = vec4_to_vec3(model_mat * vec3_to_vec4(mesh.vertices[mesh.indices[i][0]], 1.f));
		Vector3f p1 = vec4_to_vec3(model_mat * vec3_to_vec4(mesh.vertices[mesh.indices[i][3]], 1.f));
		Vector3f p2 = vec4_to_vec3(model_mat * vec3_to_vec4(mesh.vertices[mesh.indices[i][6]], 1.f));
		Vector2f uv0 = mesh.uvs[mesh.indices[i][1]];
		Vector2f uv1 = mesh.uvs[mesh.indices[i][4]];
		Vector2f uv2 = mesh.uvs[mesh.indices[i][7]];
		Vector3f norm0 = vec4_to_vec3(norm_mat * vec3_to_vec4(mesh.norms[mesh.indices[i][2]], 0.f));
		Vector3f norm1 = vec4_to_vec3(norm_mat * vec3_to_vec4(mesh.norms[mesh.indices[i][5]], 0.f));
		Vector3f norm2 = vec4_to_vec3(norm_mat * vec3_to_vec4(mesh.norms[mesh.indices[i][8]], 0.f));
		Matrix3f TBN0 = get_TBN(p0, p1, p2, uv0, uv1, uv2, norm0);
		Matrix3f TBN1 = get_TBN(p1, p2, p0, uv1, uv2, uv0, norm1);
		Matrix3f TBN2 = get_TBN(p2, p0, p1, uv2, uv0, uv1, norm2);
		draw_one_triangle(p0, p1, p2, uv0, uv1, uv2, norm0, norm1, norm2, TBN0, TBN1, TBN2, vp);
	}
}

// ����λ�ƺ����¼���p0���λ�á�normal
void Rasterizer::displace_point(Vector3f& p0, const Vector2f& uv0, Vector3f& norm0, 
	const Matrix3f& TBN0, Texture* hmap_texture) {
	// ���¼���p0λ��
	Vector3f N0(TBN0(0, 2), TBN0(1, 2), TBN0(2, 2));
	float h = (hmap_texture->get_color(uv0.x(), uv0.y()) / 255.0f).norm();
	h = (h - 0.5f) * 0.2f;
	p0 = p0 + N0 * h;
	// ���¼���p0���norm
	int x_tex = int(uv0.x() * hmap_texture->width);
	int y_tex = int(uv0.y() * hmap_texture->height);
	float h0 = (hmap_texture->get_color(x_tex, y_tex) / 255.0f).norm();
	h0 = (h0 - 0.5f) * 0.2f;
	float hr = (hmap_texture->get_color(x_tex + 1, y_tex) / 255.0f).norm();
	hr = (hr - 0.5f) * 0.2f;
	float hu = (hmap_texture->get_color(x_tex, y_tex + 1) / 255.0f).norm();
	hu = (hu - 0.5f) * 0.2f;
	norm0 = (TBN0 * Vector3f(h0 - hr, h0 - hu, 1).normalized()).normalized();
}


void Rasterizer::draw_triangles_with_displacement_mapping() {
	// ��������ÿ�����ϣ��е㴦��������һ�����㣬Ȼ����������
	// �������㣬������������ϸ�ֳ�4��С������
	// �ڶ�ÿ��С�����Σ�����bump_fragment_shader

	Matrix4f vp = projection_mat * view_mat;
	Matrix4f norm_mat = model_mat.inverse().transpose();
	for (int i = 0; i < mesh.indices.size(); ++i) {
		// ����3����
		Vector3f p0 = vec4_to_vec3(model_mat * vec3_to_vec4(mesh.vertices[mesh.indices[i][0]], 1.f));
		Vector3f p1 = vec4_to_vec3(model_mat * vec3_to_vec4(mesh.vertices[mesh.indices[i][3]], 1.f));
		Vector3f p2 = vec4_to_vec3(model_mat * vec3_to_vec4(mesh.vertices[mesh.indices[i][6]], 1.f));
		Vector2f uv0 = mesh.uvs[mesh.indices[i][1]];
		Vector2f uv1 = mesh.uvs[mesh.indices[i][4]];
		Vector2f uv2 = mesh.uvs[mesh.indices[i][7]];
		Vector3f norm0 = vec4_to_vec3(norm_mat * vec3_to_vec4(mesh.norms[mesh.indices[i][2]], 0.f));
		Vector3f norm1 = vec4_to_vec3(norm_mat * vec3_to_vec4(mesh.norms[mesh.indices[i][5]], 0.f));
		Vector3f norm2 = vec4_to_vec3(norm_mat * vec3_to_vec4(mesh.norms[mesh.indices[i][8]], 0.f));
		Vector3f p3 = (p0 + p1) * 0.5, p4 = (p1 + p2) * 0.5, p5 = (p2 + p0) * 0.5;
		Vector2f uv3 = (uv0 + uv1) * 0.5, uv4 = (uv1 + uv2) * 0.5, uv5 = (uv2 + uv0) * 0.5;
		Vector3f norm3 = (norm0 + norm1) * 0.5, norm4 = (norm1 + norm2) * 0.5, norm5 = (norm2 + norm0) * 0.5;

		// ����ÿ�����TBN
		Matrix3f TBN0 = get_TBN(p0, p1, p2, uv0, uv1, uv2, norm0);
		Matrix3f TBN1 = get_TBN(p1, p2, p0, uv1, uv2, uv0, norm1);
		Matrix3f TBN2 = get_TBN(p2, p0, p1, uv2, uv0, uv1, norm2);
		Matrix3f TBN3 = get_TBN(p3, p5, p0, uv3, uv5, uv0, norm3);
		Matrix3f TBN4 = get_TBN(p4, p2, p5, uv4, uv2, uv5, norm4);
		Matrix3f TBN5 = get_TBN(p5, p0, p3, uv5, uv0, uv3, norm5);

		// ����TBN����ÿ�����λ�ƺ��λ�ã�λ�ƺ�ķ�����
		displace_point(p0, uv0, norm0, TBN0, norm_map_texture);
		displace_point(p1, uv1, norm1, TBN1, norm_map_texture);
		displace_point(p2, uv2, norm2, TBN2, norm_map_texture);
		displace_point(p3, uv3, norm3, TBN3, norm_map_texture);
		displace_point(p4, uv4, norm4, TBN4, norm_map_texture);
		displace_point(p5, uv5, norm5, TBN5, norm_map_texture);
		
		//��Ⱦϸ�ֺ��4�������Σ�ʹ��bump_fragment_shader
		// top triangle
		draw_one_triangle(p0, p3, p5, uv0, uv3, uv5, norm0, norm3, norm5, TBN0, TBN3, TBN5, vp);
		// bottom left triangle
		draw_one_triangle(p3, p1, p4, uv3, uv1, uv4, norm3, norm1, norm4, TBN3, TBN1, TBN4, vp);
		// bottom middle triangle
		draw_one_triangle(p3, p4, p5, uv3, uv4, uv5, norm3, norm4, norm5, TBN3, TBN4, TBN5, vp);
		// bottom right triangle
		draw_one_triangle(p5, p4, p2, uv5, uv4, uv2, norm5, norm4, norm2, TBN5, TBN4, TBN2, vp);
	}
}

