#include "mesh.h"
#include "rasterizer.h"

Eigen::Matrix4f get_view_matrix(const Vector3f& campos, const Vector3f& lookto, const Vector3f& yup)
{
    Vector3f z = (campos - lookto).normalized();
    Vector3f x = yup.cross(z).normalized();
    Vector3f y = z.cross(x);
    Matrix4f view_mat;
    view_mat << x[0], x[1], x[2], 0.0f,
        y[0], y[1], y[2], 0.0f,
        z[0], z[1], z[2], 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f;
    Eigen::Matrix4f trans = Eigen::Matrix4f::Identity();
    trans(0, 3) = -campos[0];
    trans(1, 3) = -campos[1];
    trans(2, 3) = -campos[2];
    view_mat = view_mat * trans;

    return view_mat;
}

Eigen::Matrix4f get_model_matrix(float angle)
{
    //Eigen::Matrix4f model = Eigen::Matrix4f::Identity();
    //AngleAxisf rot(rotation_angle * 3.14159265f / 180.0f, Vector3f(0, 0, 1));
    //Isometry3f tt = Isometry3f::Identity();
    //tt.rotate(rot);
    
    //return tt.matrix();

    Eigen::Matrix4f rotation;
    angle = angle * 3.14159265 / 180.f;
    rotation << cos(angle), 0, sin(angle), 0,
        0, 1, 0, 0,
        -sin(angle), 0, cos(angle), 0,
        0, 0, 0, 1;

    Eigen::Matrix4f scale;
    scale << 2.5, 0, 0, 0,
        0, 2.5, 0, 0,
        0, 0, 2.5, 0,
        0, 0, 0, 1;

    Eigen::Matrix4f translate;
    translate << 1, 0, 0, 0,
        0, 1, 0, 0,
        0, 0, 1, 0,
        0, 0, 0, 1;

    return translate * rotation * scale;
}

// ͶӰ������õ�����ϵͳ��games101�γ�����һ�£��� zNear��zFar���Ǹ�ֵ��
// ͶӰ�任������ͶӰ��[-1,1]���������У���ʱz��ֵԽ�󣬾����������
Eigen::Matrix4f get_projection_matrix(float eye_fov, float aspect_ratio,
    float zNear, float zFar)
{
    // Students will implement this function

    Eigen::Matrix4f projection = Eigen::Matrix4f::Identity();

    // TODO: Implement this function
    // Create the projection matrix for the given parameters.
    // Then return it.

    float tan_half_fov = tan(eye_fov / 2.0f / 180.0f * 3.14159265f);
    float t_ = -zNear * tan_half_fov; // znear and zfar are negative
    float r_ = t_ * aspect_ratio;
    projection << zNear / r_, 0.f, 0.f, 0.f,
        0.f, zNear / t_, 0.f, 0.f,
        0.f, 0.f, (zFar + zNear) / (zNear - zFar), 2.0f * zNear * zFar / (zFar - zNear),
        0.f, 0.f, 1.f, 0.f;
           
    return projection;
}

/****************************************** fragment shaders ***************************************************/
Eigen::Vector3f normal_fragment_shader(const FragmentInfo& frag_info) {
    Eigen::Vector3f return_color = (frag_info.normal.head<3>().normalized() + Eigen::Vector3f(1.0f, 1.0f, 1.0f)) / 2.f;
    Eigen::Vector3f result;
    result << return_color.x(), return_color.y(), return_color.z();
    return result;
}

struct light {
    Eigen::Vector3f position;
    Eigen::Vector3f intensity;
};

Vector3f phong_fragment_shader(const FragmentInfo& frag_info)
{
    //frag_info.color = Vector3f(148. / 255., 121.0 / 255., 92.0 / 255.);
    Eigen::Vector3f ka = Eigen::Vector3f(0.005, 0.005, 0.005);
    Eigen::Vector3f kd = Vector3f(148. / 255., 121.0 / 255., 92.0 / 255.);
    Eigen::Vector3f ks = Eigen::Vector3f(0.7937, 0.7937, 0.7937);

    auto l1 = light{ {20, 20, 20}, {500, 500, 500} };
    auto l2 = light{ {-20, 20, 0}, {500, 500, 500} };

    std::vector<light> lights = { l1, l2 };
    Eigen::Vector3f amb_light_intensity{ 10, 10, 10 };
    Eigen::Vector3f eye_pos{ 0, 0, 10 };

    float p = 150;

    Eigen::Vector3f color(148./255., 121.0/255., 92.0/255.);
    Eigen::Vector3f point = frag_info.world_pos;
    Eigen::Vector3f normal = frag_info.normal;

    Eigen::Vector3f result_color = { 0, 0, 0 };
    for (auto& light : lights)
    {
        // TODO: For each light source in the code, calculate what the *ambient*, *diffuse*, and *specular* 
        // components are. Then, accumulate that result on the *result_color* object.
        Vector3f light_dir = light.position - point;
        float r_ = light_dir.norm();
        light_dir.normalize();
        Vector3f diffuse = std::max(0.f, frag_info.normal.dot(light_dir)) / (r_ * r_) *
            kd.cwiseProduct(light.intensity);

        Vector3f view_dir = eye_pos - point;
        view_dir.normalize();
        Vector3f half_vec = (light_dir + view_dir).normalized();
        Vector3f specular = pow(std::max(0.f, frag_info.normal.dot(half_vec)), p) / (r_ * r_) *
            ks.cwiseProduct(light.intensity);
        
        result_color += specular + diffuse + ka.cwiseProduct(amb_light_intensity);
    }
    return result_color;
}


Eigen::Vector3f texture_fragment_shader(const FragmentInfo& frag_info)
{
    Eigen::Vector3f return_color = { 0, 0, 0 };
    Eigen::Vector3f texture_color;
    texture_color << return_color.x(), return_color.y(), return_color.z();
    if (frag_info.texture)
    {
        // TODO: Get the texture value at the texture coordinates of the current fragment
        texture_color = frag_info.texture->get_color(frag_info.tex_coords.x(), frag_info.tex_coords.y());
    }
    
    Eigen::Vector3f ka = Eigen::Vector3f(0.005, 0.005, 0.005);
    Eigen::Vector3f kd = texture_color / 255.f;
    //std::cout << kd << std::endl;
    Eigen::Vector3f ks = Eigen::Vector3f(0.7937, 0.7937, 0.7937);

    auto l1 = light{ {20, 20, 20}, {500, 500, 500} };
    auto l2 = light{ {-20, 20, 0}, {500, 500, 500} };

    std::vector<light> lights = { l1, l2 };
    Eigen::Vector3f amb_light_intensity{ 10, 10, 10 };
    Eigen::Vector3f eye_pos{ 0, 0, 10 };

    float p = 150;

    Eigen::Vector3f color = texture_color;
    Eigen::Vector3f point = frag_info.world_pos;
    Eigen::Vector3f normal = frag_info.normal;

    Eigen::Vector3f result_color = { 0, 0, 0 };

    for (auto& light : lights)
    {
        // TODO: For each light source in the code, calculate what the *ambient*, *diffuse*, and *specular* 
        // components are. Then, accumulate that result on the *result_color* object.

        Vector3f light_dir = light.position - point;
        float r_ = light_dir.norm();
        light_dir.normalize();
        Vector3f diffuse = std::max(0.f, frag_info.normal.dot(light_dir)) / (r_ * r_) *
            kd.cwiseProduct(light.intensity);

        Vector3f view_dir = eye_pos - point;
        view_dir.normalize();
        Vector3f half_vec = (light_dir + view_dir).normalized();
        Vector3f specular = pow(std::max(0.f, frag_info.normal.dot(half_vec)), p) / (r_ * r_) *
            ks.cwiseProduct(light.intensity);

        result_color += specular + diffuse + ka.cwiseProduct(amb_light_intensity);
    }
    return result_color;
}


Eigen::Vector3f bump_fragment_shader(const FragmentInfo& frag_info) {

    Eigen::Vector3f ka = Eigen::Vector3f(0.005, 0.005, 0.005);
    Eigen::Vector3f kd = frag_info.texture->get_color(frag_info.tex_coords.x(), frag_info.tex_coords.y()) / 255.0f;
    Eigen::Vector3f ks = Eigen::Vector3f(0.7937, 0.7937, 0.7937);

    auto l1 = light{ {20, 20, 20}, {500, 500, 500} };
    auto l2 = light{ {-20, 20, 0}, {500, 500, 500} };

    std::vector<light> lights = { l1, l2 };
    Eigen::Vector3f amb_light_intensity{ 10, 10, 10 };
    Eigen::Vector3f eye_pos{ 0, 0, 10 };

    float p = 150;

    Eigen::Vector3f point = frag_info.world_pos;
    // ����normal
    int x_tex = int(frag_info.tex_coords.x() * frag_info.norm_map_texture->width);
    int y_tex = int(frag_info.tex_coords.y() * frag_info.norm_map_texture->height);
    float h0 = (frag_info.norm_map_texture->get_color(x_tex, y_tex) / 255.0f).norm();
    h0 = (h0 - 0.5f) * 0.2f;
    float hr = (frag_info.norm_map_texture->get_color(x_tex+1, y_tex) / 255.0f).norm();
    hr = (hr - 0.5f) * 0.2f;
    float hu = (frag_info.norm_map_texture->get_color(x_tex, y_tex+1) / 255.0f).norm();
    hu = (hu - 0.5f) * 0.2f;
    Eigen::Vector3f normal(h0-hr, h0-hu, 1);
    normal = (frag_info.TBN * normal.normalized()).normalized();

    Eigen::Vector3f result_color = { 0, 0, 0 };
    for (auto& light : lights)
    {
        // TODO: For each light source in the code, calculate what the *ambient*, *diffuse*, and *specular* 
        // components are. Then, accumulate that result on the *result_color* object.

        Vector3f light_dir = light.position - point;
        float r_ = light_dir.norm();
        light_dir.normalize();
        Vector3f diffuse = std::max(0.f, normal.dot(light_dir)) / (r_ * r_) *
            kd.cwiseProduct(light.intensity);

        Vector3f view_dir = eye_pos - point;
        view_dir.normalize();
        Vector3f half_vec = (light_dir + view_dir).normalized();
        Vector3f specular = pow(std::max(0.f, normal.dot(half_vec)), p) / (r_ * r_) *
            ks.cwiseProduct(light.intensity);

        result_color += specular + diffuse + ka.cwiseProduct(amb_light_intensity);
    }
    return result_color;
}

int main() {

    Texture tex_0("models\\spot\\spot_texture.png", 1024, 1024, 3); // ţţ����ͼ
    Texture tex_hmap("models\\spot\\hmap.jpg", 800, 800, 3); // bump mapping ͼ

    // �ڴ�����ʹ���ĸ�fragment shader, ѡ���У�normal��phong, texture, bump�� displacement
    const std::string frag_shader_name = "normal";
     

    float angle = 140.0f;
    // ������դ����Ⱦ��
	Rasterizer rd(700, 700,  45.0f, -0.1f, -50.0f);
    // ����model�任����
    rd.set_model_mat(get_model_matrix(angle));
    //rd.set_model_mat(get_model_matrix(Vector3f(0,0,1), angle));
    // ����view�任����
    rd.set_view_mat(get_view_matrix(Vector3f(0., 0., 10.), Vector3f(0., 0., 0.), Vector3f(0., 1., 0.)));
    // ����projection�任����
    rd.set_projection_mat(get_projection_matrix(45.f, 1.f, -0.1f, -50.f));
    // ��ȡ����
    rd.mesh.load_model("models\\spot\\spot_triangulated_good.obj");

    // ��Ⱦ�����α߿�
    rd.clear_color_buffer();
    rd.clear_depth_buffer();

    if (frag_shader_name == "normal") {
        rd.frag_shader = normal_fragment_shader;
    }
    else if(frag_shader_name == "phong") {
        rd.frag_shader = phong_fragment_shader;
    }
    else if (frag_shader_name == "texture") {
        rd.texture = &tex_0;
       // std::cout << "rd tex " << frag_info.texture << std::endl;
        rd.frag_shader = texture_fragment_shader;
    }
    else if (frag_shader_name == "bump") {
        rd.texture = &tex_0;
        rd.norm_map_texture = &tex_hmap;
        rd.frag_shader = bump_fragment_shader;
    }
    else if (frag_shader_name == "displacement") {
        rd.texture = &tex_0;
        rd.norm_map_texture = &tex_hmap;
        rd.frag_shader = bump_fragment_shader;
    }
    else {
        std::cout << "unknown fragment shader type" << std::endl;
        exit(1);
    }

    if (frag_shader_name == "displacement") {
        rd.draw_triangles_with_displacement_mapping();
    }
    else {
        rd.draw_triangles();
    }
	// ��������ͼ��
	rd.write_color_to_image("output.png");
}